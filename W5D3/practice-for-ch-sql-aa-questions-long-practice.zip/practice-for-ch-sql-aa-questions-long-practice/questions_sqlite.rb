require_relative 'connection'

class Questions
  attr_accessor :id, :title, :body, :author_id

  def self.all
    data = QuestionsDBConnection.instance.execute("SELECT * FROM questions")
    data.map { |question| Questions.new(question) }
  end

  def initialize(option)
    @id = option['id']
    @title = option['title']
    @body = option['body']
    @author_id = option['author_id']
  end

  def self.find_by_id(id)
    question = QuestionsDBConnection.instance.execute(<<-SQL, id)
      SELECT
        *
      FROM
        questions
      WHERE
        id = ?
    SQL
    Questions.new(question.first)
  end

  def self.find_by_author_id(author_id)
    question = QuestionsDBConnection.instance.execute(<<-SQL, author_id)
      SELECT
        *
      FROM
        questions
      WHERE
        author_id = ?
    SQL
    Questions.new(question.first)
  end

  def self.most_liked(n)
    QuestionLikes.most_liked_questions(n)
  end

  def self.most_followed(n)
    QuestionFollows.most_followed_questions(n)
  end

  def create
    raise "#{self} already in database" if self.id
    QuestionsDBConnection.instance.execute(<<-SQL, self.title, self.body, self.author_id)
      INSERT INTO
        questions (title, body, author_id)
      VALUES
        (?, ?, ?)
    SQL
    self.id = QuestionsDBConnection.instance.last_insert_row_id
  end

  def update
    raise "#{self} not in database" unless self.id
    QuestionsDBConnection.instance.execute(<<-SQL, self.title, self.body, self.author_id, self.id)
      UPDATE
        questions
      SET
        title = ?, body = ?, author_id = ?
      WHERE
        id = ?
    SQL
  end

  def self.find_by_title(title)
    question = QuestionsDBConnection.instance.execute(<<-SQL, title)
      SELECT
        *
      FROM
        questions
      WHERE
        title = ?
    SQL
    Questions.new(question.first)
  end

  def author
    User.find_by_id(self.author_id)
  end

  def replies
    Replies.find_by_question_id(self.id)
  end

  def followers
    QuestionFollows.followers_for_question_id(self.id)
  end

  def self.most_followed(n)
    QuestionFollows.most_followed_questions(n)
  end

  def likers
    QuestionLikes.likers_for_question_id(self.id)
  end

  def num_likes
    QuestionLikes.num_likes_for_question_id(self.id)
  end
end






class QuestionLikes
  attr_accessor :id, :user_id, :question_id

  def self.all
    data = QuestionsDBConnection.instance.execute("SELECT * FROM question_likes")
    data.map { |reply| Replies.new(reply) }
  end

  def initialize(option)
    @id = option['id']
    @user_id = option['user_id']
    @question_id = option['question_id']
  end

  def self.liked_questions_for_user_id(user_id)
    question = QuestionsDBConnection.instance.execute(<<-SQL, user_id)
      SELECT
        *
      FROM
        question_likes
      JOIN
        questions ON question_likes.question_id = questions.id
      WHERE
        user_id = ?
    SQL
    Questions.new(question.first)
  end

  def self.likers_for_question_id(question_id)
    question = QuestionsDBConnection.instance.execute(<<-SQL, question_id)
      SELECT
        *
      FROM
        question_likes
      JOIN
        users ON question_likes.author_id = users.id
      WHERE
        question_id = ?
    SQL
    Users.new(question.first)
  end

  def self.num_likes_for_question_id(question_id)
    question = QuestionsDBConnection.instance.execute(<<-SQL, question_id)
      SELECT
        COUNT(*)
      FROM
        question_likes
      WHERE
        question_id = ?
    SQL
    question.first
  end

  def self.liked_questions_for_user_id(user_id)
    question = QuestionsDBConnection.instance.execute(<<-SQL, user_id)
      SELECT
        *
      FROM
        question_likes
      JOIN
        questions ON question_likes.question_id = questions.id
      WHERE
        user_id = ?
    SQL
    Questions.new(question.first)
  end

  def self.most_liked_questions(n)
    question = QuestionsDBConnection.instance.execute(<<-SQL, n)
      SELECT
        *
      FROM
        question_likes
      JOIN
        questions ON question_likes.question_id = questions.id
      GROUP BY
        question_likes.question_id
      ORDER BY
        COUNT(question_likes.author_id) DESC
      LIMIT
        ?
    SQL
    question.map { |question| Questions.new(question) }
  end


end

class QuestionFollows
  attr_accessor :id, :user_id, :question_id

  def self.all
    data = QuestionsDBConnection.instance.execute("SELECT * FROM question_follows")
    data.map { |reply| Replies.new(reply) }
  end

  def initialize(option)
    @id = option['id']
    @user_id = option['user_id']
    @question_id = option['question_id']
  end

  def self.followed_questions_for_user_id(id)
    question = QuestionsDBConnection.instance.execute(<<-SQL, id)
      SELECT
        *
      FROM
        question_follows
      JOIN
        questions ON question_follows.question_id = question.id
      WHERE
        user_id = ?
    SQL
    Questions.new(question.first)
  end

  def self.followers_for_question_id(id)
    question = QuestionsDBConnection.instance.execute(<<-SQL, id)
      SELECT
        *
      FROM
        question_follows
      JOIN
        users ON question_follows.author_id = users.id
      WHERE
        question_id = ?
    SQL
    Users.new(question.first)
  end

  def self.most_followed_questions(n)
    question = QuestionsDBConnection.instance.execute(<<-SQL, n)
      SELECT
        *
      FROM
        question_follows
      JOIN
        questions ON question_follows.question_id = questions.id
      GROUP BY
        question_follows.question_id
      ORDER BY
        COUNT(question_follows.author_id) DESC
      LIMIT
        ?
    SQL
    question.map { |question| Questions.new(question) }
  end

end





class Replies
  attr_accessor :id, :question_id, :parent_id, :user_id, :body

  def self.all
    data = QuestionsDBConnection.instance.execute("SELECT * FROM replies")
    data.map { |reply| Replies.new(reply) }
  end

  def initialize(option)
    @id = option['id']
    @question_id = option['question_id']
    @parent_id = option['parent_id']
    @user_id = option['user_id']
    @body = option['body']
  end

  def self.find_by_id(id)
    reply = QuestionsDBConnection.instance.execute(<<-SQL, id)
      SELECT
        *
      FROM
        replies
      WHERE
        id = ?
    SQL
    Replies.new(reply.first)
  end

  def self.find_by_question_id(question_id)
    reply = QuestionsDBConnection.instance.execute(<<-SQL, question_id)
      SELECT
        *
      FROM
        replies
      WHERE
        question_id = ?
    SQL
    Replies.new(reply.first)
  end

  def self.find_by_parent_id(parent_id)
    reply = QuestionsDBConnection.instance.execute(<<-SQL, parent_id)
      SELECT
        *
      FROM
        replies
      WHERE
        parent_id = ?
    SQL
    Replies.new(reply.first)
  end

  def create
    raise "#{self} already in database" if self.id
    QuestionsDBConnection.instance.execute(<<-SQL, self.question_id, self.parent_id, self.user_id, self.body)
      INSERT INTO
        replies (question_id, parent_id, user_id, body)
      VALUES
        (?, ?, ?, ?)
    SQL
    self.id = QuestionsDBConnection.instance.last_insert_row_id
  end


  def author
    User.find_by_id(self.user_id)
  end

  def question
    Questions.find_by_id(self.question_id)
  end

  def parent_reply
    Replies.find_by_id(self.parent_id)
  end

  def child_replies
    reply = QuestionsDBConnection.instance.execute(<<-SQL, self.id)
      SELECT
        *
      FROM
        replies
      WHERE
        parent_id = ?
    SQL
    Replies.new(reply.first)
  end
  def update
    raise "#{self} not in database" unless self.id
    QuestionsDBConnection.instance.execute(<<-SQL, self.question_id, self.parent_id, self.user_id, self.body, self.id)
      UPDATE
        replies
      SET
        question_id = ?, parent_id = ?, user_id = ?, body = ?
      WHERE
        id = ?
    SQL
  end

end







class Users
  attr_accessor :id, :fname, :lname
  def self.all
    data = QuestionsDBConnection.instance.execute("SELECT * FROM users")
    data.map { |reply| Replies.new(reply) }
  end

  def initialize(option)
    @id = option['id']
    @fname = option['fname']
    @lname = option['lname']
  end

  def create
    raise "#{self} already in database" if self.id
    QuestionsDBConnection.instance.execute(<<-SQL, self.fname, self.lname)
      INSERT INTO
        users (fname, lname)
      VALUES
        (?, ?)
    SQL
    self.id = QuestionsDBConnection.instance.last_insert_row_id
  end

  def self.find_by_id(id)
    user = QuestionsDBConnection.instance.execute(<<-SQL, id)
      SELECT
        *
      FROM
        users
      WHERE
        id = ?
    SQL
    Users.new(user.first)
  end

  def update
    raise "#{self} not in database" unless self.id
    QuestionsDBConnection.instance.execute(<<-SQL, self.fname, self.lname, self.id)
      UPDATE
        users
      SET
        fname = ?, lname = ?
      WHERE
        id = ?
    SQL
  end

  def self.find_by_name(name)
    user = QuestionsDBConnection.instance.execute(<<-SQL, name)
      SELECT
        *
      FROM
        users
      WHERE
        fname = ?
    SQL
    Users.new(user.first)
  end

  def authored_questions
    Questions.find_by_author_id(self.id)
  end

  def authored_replies
    Replies.find_by_user_id(self.id)
  end

  def followed_questions
    QuestionFollows.followed_questions_for_user_id(self.id)
  end

  def liked_question
    QuestionLikes.liked_questions_for_user_id(self.id)
  end

  #Average number of likes for a User's questions.
  def average_karma
    question = QuestionsDBConnection.instance.execute(<<-SQL, self.id)
      SELECT
        COUNT(question_likes.author_id) / CAST(COUNT(DISTINCT(questions.id)) AS FLOAT)
      FROM
        questions
      LEFT OUTER JOIN
        question_likes ON questions.id = question_likes.question_id
      WHERE
        questions.author_id = ?
    SQL
    question.first
  end
end
